
import java.util.Random;
import java.util.Scanner;

public class GuessNumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        boolean playAgain = true;

        System.out.println("Welcome to the Number Guessing Game!");

        while (playAgain) {
            int targetNumber = random.nextInt(100) + 1;
            int attempts = 0;
            int maxAttempts = 10; // You can set the limit here
            System.out.println("\nI have generated a number between 1 and 100. Can you guess it?");

            while (attempts < maxAttempts) {
                System.out.printf("Attempt %d/%d. Enter your guess: ", attempts + 1, maxAttempts);
                int guess = scanner.nextInt();
                attempts++;

                if (guess < targetNumber) {
                    System.out.println("Too low!");
                } else if (guess > targetNumber) {
                    System.out.println("Too high!");
                } else {
                    System.out.printf("Congratulations! You guessed the number in %d attempts.%n", attempts);
                    break;
                }
            }

            if (attempts == maxAttempts) {
                System.out.printf("Sorry, you've used all %d attempts. The correct number was %d.%n", maxAttempts, targetNumber);
            }

            System.out.print("Do you want to play again? (yes/no): ");
            String playAgainInput = scanner.next();
            playAgain = playAgainInput.equalsIgnoreCase("yes");
        }

        scanner.close();
        System.out.println("Thank you for playing!");
    }
}